//
//  detailsViewController.swift
//  AlamofireJsonDemo
//
//  Created by Mac on 7/26/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class detailsViewController: UIViewController {
    @IBOutlet weak var lblAddress: UILabel!
    
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    
    
    var strEmail = ""
    var strGender = ""
    var strAddress = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblEmail.text = strEmail
        lblGender.text = strGender
        lblAddress.text = strAddress
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

   
}
