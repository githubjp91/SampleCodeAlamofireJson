//
//  ViewController.swift
//  AlamofireJsonDemo
//
//  Created by agile-13 on 19/07/18.
//  Copyright © 2018 Agile. All rights reserved.


import UIKit
import Alamofire

class ViewController: UIViewController {
   
    
    @IBOutlet weak var tblView: UITableView!
    
    var arry = [AnyObject]()
    
    override func viewDidLoad(){
        super.viewDidLoad()
        tblView.rowHeight = 100

//    http://api.androidhive.info/contacts/
      
        
         Alamofire.request("http://api.androidhive.info/contacts/").responseJSON { (response:DataResponse) in
            let result = response.result
            if let dic = result.value as? Dictionary<String,AnyObject>
            {
                if let inrDic = dic["contacts"]
                {
                    print(dic["contacts"]as AnyObject)
                    self.arry = inrDic as! [AnyObject]
                    
                    self.tblView.reloadData()
                }
            }
            
      
//        Alamofire.request("http://api.androidhive.info/contacts/").responseJSON { (response:DataResponse<Any>) in
//
//
//
//            switch(response.result)
//            {
//            case .success(_):
//
//                if response.result.value  != nil
//                {
//
//
//                    print(response.result.value!)
//
         
//
//                }
//                break
//
//            case .failure(_):
//
//                print(response.result.error as Any)
//                break
//
//            }
//
//        }
//        }
//
//
    
}

}
}
extension ViewController: UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arry.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {

        let cell = tableView.dequeueReusableCell(withIdentifier: "cusTableViewCell", for: indexPath)as! cusTableViewCell

        cell.lblName.text = arry[indexPath.row]["id"]as AnyObject as? String
        cell.lblRegion.text = arry[indexPath.row]["name"]as AnyObject as? String

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
        
        let Details:detailsViewController = self.storyboard?.instantiateViewController(withIdentifier: "detailsViewController")as! detailsViewController

     
        
        let dict:NSDictionary = arry[indexPath.row] as! NSDictionary
        
        print("*************API************")

        print(dict)
        
        Details.strEmail = dict["email"]as! String
        Details.strGender = dict["gender"]as! String
        Details.strAddress = dict["address"]as! String
        
        self.tblView.reloadData()
        self.navigationController?.pushViewController(Details, animated: true)
        
    }

}

