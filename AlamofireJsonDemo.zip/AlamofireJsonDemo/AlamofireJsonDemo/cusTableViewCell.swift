//
//  cusTableViewCell.swift
//  AlamofireJsonDemo
//
//  Created by Mac on 7/25/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class cusTableViewCell: UITableViewCell {
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblRegion: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    

}
